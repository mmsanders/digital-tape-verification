param([Parameter(Mandatory=$true)][string]$Consent)
throw 'Verification359 HELD: new PowerShell controls did not execute; this authoring publication grants NO launch admission'
$ArtifactDir='C:\Users\mrtro\DigitalTape-618-kit\Digital-Tape';$WorkDir='C:\Users\mrtro\DigitalTape-618-kit\receipts\native618-1';$Python='C:\Program Files\Inkscape\bin\python.exe';$ToolContext='manual-software-resumption-existing-auto-mode'
$DataRoot='C:\Users\mrtro\AppData\Local\org.digitaltape.app';$publication='7b80c14b6c7825bd3876c05d9f988b81c23526e3';$methodSha='d4f0178c58ef9e6afbe1c5dedd2ed6aca6718ad8de5047d2d3b5b1536108ce41';$commandSha='574f96ca108ef1c0badaf3c2bf2fd8b1f5e4717eab90747c298f6ae34d0affda'
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'window_gate.ps1')
. (Join-Path $PSScriptRoot 'session_gate.ps1')
. (Join-Path $PSScriptRoot 'session_io.ps1')
function Ordinary-Path([string]$Path,[bool]$Directory) {
  $full=[IO.Path]::GetFullPath($Path)
  if ($full.StartsWith('\\') -or $full.Substring(2).Contains(':')) { throw 'Nonordinary path' }
  $item=Get-Item -LiteralPath $full
  if ($item.PSIsContainer -ne $Directory) { throw 'Wrong file/directory type' }
  $cursor=$item
  while ($null -ne $cursor) {
    if (($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Reparse component' }
    if ($cursor.PSIsContainer) { $cursor=$cursor.Parent } else { $cursor=$cursor.Directory }
  }
  return $full
}
$artifact=Ordinary-Path $ArtifactDir $true
$pythonPath=Ordinary-Path $Python $false
if ((Get-FileHash -LiteralPath $pythonPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne 'fbaff2f38852ac61c5767a91d5efbd4d893fb8ca985a9fdc76cf6d88fb93a745') { throw 'Existing Python pin mismatch' }
$work=[IO.Path]::GetFullPath($WorkDir)
if (Test-Path -LiteralPath $work) { throw 'Fresh WorkDir required; preserve originals' }
[void](Ordinary-Path ([IO.Path]::GetDirectoryName($work)) $true)
if ($work.StartsWith('\\') -or $work.Substring(2).Contains(':')) { throw 'Nonordinary output' }
[void](New-Item -ItemType Directory -Path $work -ErrorAction Stop)
$pins=@{
 'digital-tape.exe'='ccae0cf5098aed601fd17b4af1c0d62a33ad28dfb734add1c5df3a67df807c96';
 'ingest.exe'='3895f3f356c91b8a9fe870c33694da64bf2765df308bef118d657c1be4bb9a20';
 'tapectl.exe'='44ef26869ba2d01a8a183660a2c7a050d0e7e9ff37c40b727131512739ea6ded'
}
$facts=[ordered]@{case='native618-one-session';method_publication='7b80c14b6c7825bd3876c05d9f988b81c23526e3';method_sha256='d4f0178c58ef9e6afbe1c5dedd2ed6aca6718ad8de5047d2d3b5b1536108ce41';consent_route='manual-software-resumption-existing-auto-mode';terminal_polls_observed=0;live_samples=@();diagnostic_copy_complete=$false;collection_error=$null;parent_identity=$null;source='fce1d644f03ed1220e40133be0c33bd30e519203';
 start_utc=[DateTime]::UtcNow.ToString('o');parent_pid=$PID;cwd=$artifact;argv=@();pins=$pins;
 tool_route=$ToolContext;samples=@();native_window_ready=$false;page_readiness='UNEXECUTED / no actual page observer';
 ui_interaction='UNEXECUTED';selected_webview2_runtime='UNAVAILABLE: module/child evidence not yet observed';
 close_posted=$false;graceful_exit=$false;forced_owned_cleanup=$false;capture_complete=$false;verdict='STOP'}
function Save-Facts { $facts | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $work 'launch.private.json') -Encoding utf8 }
$p=$null;$started=$false;$outFile=$null;$errFile=$null;$outTask=$null;$errTask=$null;$clock=$null
try {
  Save-Facts
  $consentPath=Ordinary-Path $Consent $false
  if ($consentPath -ine 'C:\Users\mrtro\DigitalTape-618-kit\consent618.json') { throw 'Wrong consent file' }
  $consentRecord=Get-Content -LiteralPath $consentPath -Raw | ConvertFrom-Json
  if (!(Test-ManualConsent $consentRecord $commandSha $publication $methodSha)) { throw 'Missing exact-method manual resumption; no launch' }
  $facts.consent=$consentRecord;$facts.consent_sha256=(Get-FileHash -LiteralPath $consentPath -Algorithm SHA256).Hash.ToLowerInvariant()
  $facts.per_command_prompt=$false;$facts.permission_mode='auto';$facts.policy_changed=$false
  $prepared=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PREPARED.json') -Raw | ConvertFrom-Json
  if ($prepared.publication -cne $publication -or $prepared.method_sha256 -cne $methodSha -or $prepared.command_sha256 -cne $commandSha) { throw 'Prepared method mismatch' }
  if (@($prepared.files.PSObject.Properties).Count -ne 7) { throw 'Incomplete prepared helper set' }
  foreach ($property in $prepared.files.PSObject.Properties) {
    if ($property.Name -notin @('Start-Session.ps1','context.py','window_gate.ps1','WindowNative.cs','METHOD.json','session_gate.ps1','session_io.ps1')) { throw 'Unknown prepared file' }
    $preparedFile=Ordinary-Path (Join-Path $PSScriptRoot $property.Name) $false
    if ((Get-FileHash -LiteralPath $preparedFile -Algorithm SHA256).Hash.ToLowerInvariant() -cne $property.Value) { throw 'Prepared helper changed' }
  }
  [void](Ordinary-Path $DataRoot $true)
  if (Test-Path -LiteralPath (Join-Path $DataRoot 'control')) { throw 'Declared fresh control root is no longer absent; preserve it and STOP' }
  if (Test-Path -LiteralPath (Join-Path $DataRoot 'jobs')) {
    [void](Ordinary-Path (Join-Path $DataRoot 'jobs') $true)
    if (@(Get-ChildItem -LiteralPath (Join-Path $DataRoot 'jobs') -Force).Count -ne 0) { throw 'Existing jobs; no cleanup or overwrite' }
  }
  if (@(Get-Process -Name digital-tape,tapectl,ingest -ErrorAction SilentlyContinue).Count -ne 0) { throw 'Conflicting process; no launch' }

  $contextFile=Join-Path $work 'context.private.json'
  & $pythonPath -B (Join-Path $PSScriptRoot 'context.py') --route $ToolContext --output $contextFile
  if ($LASTEXITCODE -ne 0) { throw 'Ordinary context admission failed; no Product invocation' }
  $facts.context=Get-Content -LiteralPath $contextFile -Raw | ConvertFrom-Json
  $groups=(& whoami /groups /fo csv /nh | Out-String)
  if ($LASTEXITCODE -ne 0 -or $groups -notmatch 'S-1-16-8192') { throw 'Current Medium integrity not established' }
  $facts.integrity_groups=$groups
  $principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
  $facts.recorder_effective_admin=$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
  if ($facts.recorder_effective_admin -or $facts.context.token_elevated -or $facts.context.effective_admin -or $facts.context.parent_pid -ne $PID) { throw 'Non-admin bound recorder context required' }
  if ([IO.DriveInfo]::new([IO.Path]::GetPathRoot($work)).AvailableFreeSpace -lt 256MB) { throw 'Insufficient ordinary log/fixture headroom' }
  foreach ($name in $pins.Keys) {
    $file=Ordinary-Path (Join-Path $artifact $name) $false
    if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $pins[$name]) { throw "Bundle mismatch: $name" }
  }
  $buildPath=Ordinary-Path (Join-Path $artifact 'BUILD.json') $false
  $build=Get-Content -LiteralPath $buildPath -Raw | ConvertFrom-Json
  if ($build.source_head -ne $facts.source -or $build.s1_source -ne '35b23cacae886d9b3693b7104f581d8646ea5667' -or $build.child_version -ne '0.1.1 INGEST-1 arithmetic-profile INGEST1-AP4') { throw 'BUILD mismatch' }
  $facts.build_sha256=(Get-FileHash -LiteralPath $buildPath).Hash.ToLowerInvariant()
  if ($facts.build_sha256 -cne '276ebe08d977a2e20d8e90d87641fd6b7c390a5f0fdd244e8c4618ae7946b3ae') { throw 'Specific BUILD hash mismatch' }
  Add-Type -Path (Join-Path $PSScriptRoot 'WindowNative.cs')
  $info=[Diagnostics.ProcessStartInfo]::new()
  $info.FileName=Join-Path $artifact 'digital-tape.exe';$info.WorkingDirectory=$artifact
  $info.Arguments='--diagnostic-receipts';$facts.requested_argv=@($info.FileName,'--diagnostic-receipts');$facts.argv=$facts.requested_argv
  $info.UseShellExecute=$false;$info.CreateNoWindow=$false
  $info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $outFile=[IO.File]::Open((Join-Path $work 'stdout.bin'),[IO.FileMode]::CreateNew)
  $errFile=[IO.File]::Open((Join-Path $work 'stderr.bin'),[IO.FileMode]::CreateNew)
  $p=[Diagnostics.Process]::new();$p.StartInfo=$info
  $clock=[Diagnostics.Stopwatch]::StartNew()
  [void]$p.Start();$started=$true;$facts.pid=$p.Id;$facts.process_start_ticks=$p.StartTime.ToUniversalTime().Ticks
  $facts.launch_utc=[DateTime]::UtcNow.ToString('o')
  $outTask=$p.StandardOutput.BaseStream.CopyToAsync($outFile);$errTask=$p.StandardError.BaseStream.CopyToAsync($errFile)
  Save-Facts
  $seq=0;$ready=$null
  while ($clock.ElapsedMilliseconds -le 20000) {
    $p.Refresh();if ($p.HasExited) { break }
    $observed=@([App283Native]::Snapshot([uint32]$p.Id))
    $candidates=@($observed | Where-Object { $_.title -ceq 'Digital Tape' -and $_.visible -and $_.top_level -and $_.owner_handle -eq 0 })
    $sample=@{seq=$seq;elapsed_ms=$clock.ElapsedMilliseconds;utc=[DateTime]::UtcNow.ToString('o');pid=$p.Id;
      start_ticks=$facts.process_start_ticks;handle=0;title='';visible=$false;responding=$false;top_level=$false;owner_handle=0;ambiguous=($candidates.Count -gt 1);observed_owned_windows=$observed}
    if ($candidates.Count -eq 1) {
      $candidate=$candidates[0]
      foreach ($key in @('pid','handle','title','visible','responding','top_level','owner_handle')) { $sample[$key]=$candidate.$key }
    }
    $facts.samples+=@($sample);Save-Facts
    $ready=Get-ReadyWindow $facts.samples $p.Id $facts.process_start_ticks
    if ($null -ne $ready) { break }
    $seq++;Start-Sleep -Milliseconds 500
  }
  if ($null -ne $ready -and !$p.HasExited) {
    $facts.native_window_ready=$true;$facts.ready_elapsed_ms=$ready.elapsed_ms
    $p.Refresh()
    $image=Ordinary-Path $p.MainModule.FileName $false
    $facts.parent_identity=@{pid=$p.Id;image_path=$image;image_sha256=(Get-FileHash -LiteralPath $image -Algorithm SHA256).Hash.ToLowerInvariant();start_ticks=$p.StartTime.ToUniversalTime().Ticks;observed_utc=[DateTime]::UtcNow.ToString('o')}
    $facts.parent_identity.os_start_ns=([decimal]$facts.parent_identity.start_ticks-[decimal]621355968000000000)*100
    if ($image -ine $info.FileName -or $facts.parent_identity.image_sha256 -cne $pins['digital-tape.exe'] -or $facts.parent_identity.start_ticks -ne $facts.process_start_ticks) { throw 'Running parent identity mismatch' }
    Save-Facts
    while (!$p.HasExited -and $clock.ElapsedMilliseconds -lt $facts.ready_elapsed_ms+14750 -and $clock.ElapsedMilliseconds -lt 59000) {
      try {
        $signal=Read-LiveSession (Join-Path $DataRoot 'control') $p.Id $image $pins['digital-tape.exe'] $facts.parent_identity.os_start_ns
        $facts.terminal_polls_observed=$signal.terminal_count
        $facts.live_samples+=@(@{elapsed_ms=$clock.ElapsedMilliseconds;session=$signal.session;terminal_count=$signal.terminal_count;partial_tail=$signal.partial_tail;complete_lines=$signal.complete_lines;scope='FIRST-PARTY stop trigger only'})
        if ($signal.stopped) { $facts.close_reason='receipt-incomplete';break }
        if ($signal.terminal_count -ge 2) { $facts.close_reason='two-first-party-terminals';break }
      } catch { $facts.collection_error=$_.Exception.Message;$facts.close_reason='collection-blocker';break }
      Start-Sleep -Milliseconds 100;$p.Refresh()
    }
    if (!$facts.close_reason) { $facts.close_reason='readiness-plus15s-bound' }
    if ($p.HasExited -or $p.StartTime.ToUniversalTime().Ticks -ne $facts.process_start_ticks) { throw 'Parent exited/reused before controlled close' }
    # Revalidate the exact owned handle immediately before a normal OS WM_CLOSE.
    $fresh=@([App283Native]::Snapshot([uint32]$p.Id) | Where-Object { $_.handle -eq $ready.handle })
    $facts.preclose_owned_windows=$fresh
    if ($fresh.Count -eq 1 -and $fresh[0].title -ceq 'Digital Tape' -and $fresh[0].visible -and $fresh[0].responding -and $fresh[0].top_level -and $fresh[0].owner_handle -eq 0 -and $clock.ElapsedMilliseconds -le 60000) {
      $facts.native_window_ready=$true;$facts.ready_elapsed_ms=$ready.elapsed_ms
      $facts.close_requested_utc=[DateTime]::UtcNow.ToString('o')
      $facts.close_elapsed_ms=$clock.ElapsedMilliseconds
      if ($facts.close_elapsed_ms-$facts.ready_elapsed_ms -gt 15000) { $facts.collection_error='Close observation bound overrun' }
      $facts.close_posted=[App283Native]::Close($ready.handle,[uint32]$p.Id)
      if ($facts.close_posted) { $facts.graceful_exit=$p.WaitForExit(10000) }
    }
  }
  if (!$p.HasExited) { $facts.forced_owned_cleanup=$true;$p.Kill();[void]$p.WaitForExit(5000) }
  if ($p.HasExited) { $facts.exit=$p.ExitCode }
  $facts.capture_complete=[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($outTask,$errTask),5000)
  if ((Test-NormalQuit $facts) -and (Test-SessionBounds $facts)) { $facts.verdict='PARENT NATIVE WINDOW/CLOSE component observed; FIRST-PARTY poller records require offline review' }
} catch { $facts.error=$_.Exception.ToString() }
finally {
  if ($started -and !$p.HasExited) {
    $facts.forced_owned_cleanup=$true
    try { $p.Kill();[void]$p.WaitForExit(5000) } catch { $facts.cleanup_error=$_.Exception.Message }
  }
  if ($null -ne $outTask -and $null -ne $errTask) {
    try { $facts.capture_complete=[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($outTask,$errTask),5000) } catch { $facts.capture_error=$_.Exception.Message }
  }
  if ($null -ne $outFile) { $outFile.Dispose() };if ($null -ne $errFile) { $errFile.Dispose() }
  if ($facts.forced_owned_cleanup) { $facts.verdict='STOP / owned cleanup is not normal quit' }
  if (!(Test-NormalQuit $facts) -and $facts.verdict -like 'NATIVE WINDOW*') { $facts.verdict='STOP / incomplete final receipt' }
  try {
    if ($started) {
      $facts.diagnostic_manifest=@(Retain-Session (Join-Path $DataRoot 'control') (Join-Path $work 'diagnostic'))
      $facts.diagnostic_copy_complete=$true
      $jobsPath=Join-Path $DataRoot 'jobs'
      if (Test-Path -LiteralPath $jobsPath) {
        [void](Ordinary-Path $jobsPath $true)
        $facts.post_jobs=@(Get-ChildItem -LiteralPath $jobsPath -Force | ForEach-Object { @{name=$_.Name;directory=$_.PSIsContainer;reparse=(($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)} })
        $facts.post_jobs_status='observed; listing is not cleanup-history proof'
      } else { $facts.post_jobs_status='absent' }
    }
  } catch { $facts.retention_error=$_.Exception.Message }
  $facts.end_utc=[DateTime]::UtcNow.ToString('o')
  foreach ($name in @('stdout.bin','stderr.bin')) {
    $f=Join-Path $work $name
    if (Test-Path -LiteralPath $f) { $facts[$name+'_sha256']=(Get-FileHash -LiteralPath $f).Hash.ToLowerInvariant() }
  }
  Save-Facts
}
$facts | ConvertTo-Json -Depth 12
if (!(Test-NormalQuit $facts) -or !(Test-SessionBounds $facts) -or !$facts.diagnostic_copy_complete -or $facts.collection_error -or $facts.retention_error) { exit 1 }
