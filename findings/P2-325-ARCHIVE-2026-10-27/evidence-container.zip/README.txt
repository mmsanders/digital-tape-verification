Digital Tape - unsigned Windows11 x64 developer preview: discovery candidate (#585)

This is a NEW build of digital-tape.exe from main 1731f6ec. It includes the
cleared card discovery (#578), label and details interactions (#584) and the INGEST
console-window fix with opt-in diagnostic receipts (#594). ingest.exe is the
original, unchanged INGEST child. tapectl.exe is the accepted S2 discovery child.
Both are pinned by hash in BUILD.json, and both pins are compiled into the app.

Extract all five members into a new, ordinary folder you own and keep them
together. digital-tape.exe is the app. It needs Windows 11 x64 and the Microsoft
Edge WebView2 runtime that is normally already present on Windows 11; this bundle
does not install it. There is no installer, runtime download, signing step or
security change. Do not change security settings to run it.

What has been shown: only the bundled ingest.exe's direct checks (a music folder
accepted, an empty folder refused), run directly against that exact file and not
through this app. Nothing has been demonstrated on THIS app binary. Its startup,
window, page, label input, folder drops, Checking, Start over, Problem/Show
details, card discovery and normal close are all UNEXECUTED.

When started, this app looks for cards by itself in the background (the discovery
poller). Running it has not been admitted yet: a separate final-candidate
admission is needed first. Card discovery is a hint only. It makes no claim that a
card is safe, ready or removable.

Make cartridge is intentionally disabled. Card writing is not part of this build.
Do not run the bundled tapectl.exe or ingest.exe yourself.

Diagnostics default OFF. The app writes no diagnostic receipts unless it is started
with its single opt-in switch, and no session using that switch has been admitted.
When enabled, receipts stay in the app's private per-user CONTROL folder, capped at
16 MiB per session.

If no usable window appears, close the attempt and keep any error text. This is a
developer preview, not a qualified family release. Full APP/INGEST/CLI A6/G2 remain
held.
